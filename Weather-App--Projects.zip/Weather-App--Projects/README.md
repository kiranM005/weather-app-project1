<h1>A Weather App</h1><br>
<p><b>A weather app that pulls from the OpenWeatherMap API to allow users to search for and view the forecast in cities worldwide.</b></p><br>
<ul>
  <li>ReactJS</li>
  <li>Tailwind CSS</li>
  <li>RESTful API</li>
</ul>

<h4>Link - https://nithin0001.github.io/Weather-App/</h4>
<h4>👆 Do check it out.</h4>
